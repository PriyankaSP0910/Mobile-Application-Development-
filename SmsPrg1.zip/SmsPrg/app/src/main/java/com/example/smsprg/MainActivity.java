package com.example.smsprg;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    EditText txt1, txt2;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt1 = findViewById(R.id.editText1);
        txt2 = findViewById(R.id.editText2);
        btn = findViewById(R.id.btn);
        }
    public void click(View v) {
    try {
        SmsManager sm = SmsManager.getDefault();
        sm.sendTextMessage(txt1.getText().toString(),null,txt2.getText().toString(),null,null);
        Snackbar.make(v,"SMS sent Successfully",Snackbar.LENGTH_LONG).show();

    }
    catch (Exception e) {
        Snackbar.make(v,"SMS Not sent Successfully",Snackbar.LENGTH_LONG).show();

    }
    }
}

