(function()
{
    self.addEventListener('install',(event)=>{
        console.log("SW is installing")
        event.waitUntil(
            caches.open('PWD App').then(cache=>{
                cache.addAll(['/git'])
            })
        )
        self.skipWaiting()
    })
    self.addEventListener("activate",(event)=>
{
    console.log("SW is activationg")
    event.waitUntil(caches.delete('PWD App'));
})
    self.addEventListener('fetch',(event)=>{
        console.log("fetching",event.request.url)
              event.respondWith(caches.match(event.request).then(async(response)=>{
            if(response){
                return response;
            }
            let data=fetch(event.request)
            let data_clone=(await data).clone();
            event.waitUntil(caches.openn('PWD App').then(cache=>{
                cache.put(event.request,data_clone)
            }));
            return data;
        })
    )
    })
}
)
