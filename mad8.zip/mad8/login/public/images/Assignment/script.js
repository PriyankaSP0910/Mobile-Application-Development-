// let age = 10;
// let name = 'Prajwal';

// console.log(age);
// console.log(typeof age);

// console.log('name');
// console.log(typeof 'name');

let Student =  {
    usn:1234,
    name:'prajwal',
    sap_id:888,
};

console.log(Student);

let Student1 =  {
    usn:5656,
    name:'gautam',
    sap_id:766,
};

console.log(Student1);

