package com.example.prg4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

public class MainActivity extends AppCompatActivity {
    FragmentOne fragmentOne = new FragmentOne();
    FragmentTwo fragmentTwo = new FragmentTwo();

    int showing_frag = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.add(R.id.clayout,fragmentOne);
        ft.commit();
    }
    public void switchFrag(View v)
    {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        if(showing_frag == 1) {
            ft.replace(R.id.clayout,fragmentTwo);
            showing_frag = 2;
        }
        else {
            ft.replace(R.id.clayout,fragmentOne);
            showing_frag = 1;
        }
        ft.commit();
    }
}