package com.example.prg2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
Button btn;
ProgressBar pb;
TextView text;
int ProgressStatus =0;
Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);
        pb = findViewById(R.id.pro);
        text =findViewById(R.id.textView);
        new  Thread(new Runnable() {
            @Override
            public void run() {
                while (ProgressStatus<100)
                {
                    ProgressStatus +=1;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            pb.setProgress(ProgressStatus);
                            text.setText(ProgressStatus+"%");
                        }
                    });
                    try {
                        Thread.sleep(200);
                    }
                    catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    }
                }
        }).start();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(false);
                builder.setIcon(R.drawable.alert);
                builder.setTitle("Alert!");
                builder.setMessage("Are You sure want to Exit");
                builder.setPositiveButton("Accept" ,(dialog, which) ->
                {
                    finish();
                });
                builder.setNegativeButton("Reject" ,(dialog, which) ->
                {
                    dialog.cancel();
                });
                builder.setNeutralButton("Cancel" ,(dialog, which) ->
                {
                    dialog.cancel();
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });
    }
}