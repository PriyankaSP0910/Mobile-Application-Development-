package com.example.databaseprg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    EditText uname,paswd;
    Button login,cancel;
    DbHandler db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        uname = findViewById(R.id.editText1);
        paswd = findViewById(R.id.editText2);
        login = findViewById(R.id.button);
        cancel = findViewById(R.id.button2);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = uname.getText().toString();
                String password = paswd.getText().toString();

                int id = checkUser(new User(name,password));

                if(id==-1){
                    Snackbar.make(v,"User"+name+"Does not Exist",Snackbar.LENGTH_LONG).show();
                }
                else {
                    Snackbar.make(v,"User"+name+" Exist",Snackbar.LENGTH_LONG).show();
                    Intent i =new Intent(MainActivity.this,SecondActivity.class);
                    startActivity(i);
                }
            }
        });
        db = new DbHandler(MainActivity.this);
        db.addUser(new User("prajwal","12345"));
        db.addUser(new User("Free","Software"));
        db.addUser(new User("Hello","World"));

    }
    public int checkUser(User user) {
        return db.checkUser(user);
    }
}
